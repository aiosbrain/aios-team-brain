"""A deferred folder is settled only by listing its subtree, never by its metadata (AIO-1167 R51 final 1).

Spec (accepted-spec AC-03/05/07; Astra 20:01 UTC adjudication, finding 1). A folder root whose read
was deferred while a snapshot was being built has only a placeholder in that build — retained
membership, none on fresh local state. Reading the folder's metadata later proves where it is, not
what is under it. Through the real coordinator over ``_DriveWorld``:

  * with existing brain claims and FRESH local state, folder A deferred and the build kept open by a
    sibling larger than one run's discovery budget, a restart in which A's metadata recovers and the
    change feed is empty lists A AND its nested folder before any complete reconciliation; every
    complete snapshot holds A's documents, their claims survive, and the brain's last success does
    not move until the connection is genuinely complete;
  * with RETAINED local membership, a document under A that is gone at the provider (no change the
    stream can see) is NOT kept by the placeholder: the subtree is listed again and the complete
    snapshot retires its claim — never reported complete with stale membership;
  * a recovered listing interrupted part-way leaves A deferred and the connection incomplete; after a
    restart it resumes, lists the rest, settles A and completes.
"""

from __future__ import annotations

import pytest

from aios_ingest.gdrive_sync import _MAX_DISCOVERY_PAGES_PER_STREAM
from aios_ingest.state import StateStore
from test_document_restrictions import clock  # noqa: F401 (fixture)
from test_gdrive_upgrade import _ClaimLedger, _DriveWorld
from test_root_evidence_r49 import real_deferral

GEN = 9
DRIVE = "shared-a"
# More listings than one run may make, so a folder of this size keeps a snapshot building.
BIG = _MAX_DISCOVERY_PAGES_PER_STREAM + 5
A_DOCS = {"doc-a1", "doc-a2"}


def _world(monkeypatch, *, big_a: bool = False, big_b: bool = True):
    world = _DriveWorld(folder_ids=["folder-a", "folder-b"]).install(monkeypatch)
    world.ledger = _ClaimLedger()
    world.put("folder-a", drive=DRIVE, folder=True)
    world.put("folder-a-sub", drive=DRIVE, parent="folder-a", folder=True)
    world.put("doc-a1", drive=DRIVE, parent="folder-a")
    world.put("doc-a2", drive=DRIVE, parent="folder-a-sub")
    if big_a:
        for i in range(BIG):
            world.put(f"folder-a{i}", drive=DRIVE, parent="folder-a", folder=True)
            world.put(f"doc-ax{i}", drive=DRIVE, parent=f"folder-a{i}")
    world.put("folder-b", drive=DRIVE, folder=True)
    world.put("doc-b", drive=DRIVE, parent="folder-b")
    if big_b:
        for i in range(BIG):
            world.put(f"folder-b{i}", drive=DRIVE, parent="folder-b", folder=True)
            world.put(f"doc-b{i}", drive=DRIVE, parent=f"folder-b{i}")
    return world


async def _until_complete(world, state, limit: int = 40):
    summary = None
    for _ in range(limit):
        summary = await world.run(state)
        if summary.authoritative_complete:
            return summary
    raise AssertionError(f"not complete after {limit} runs: {summary}")


def _deferred(state, world) -> bool:
    return ("folder", "folder-a") in state.deferred_roots(world.integration_id, GEN, DRIVE)


def _listed(world, folder: str) -> bool:
    return ("list", DRIVE, folder) in world.calls


@pytest.mark.asyncio
async def test_fresh_state_with_brain_claims_lists_the_recovered_folder_before_any_complete_snapshot(
    tmp_path, monkeypatch, clock,
):
    world = _world(monkeypatch)
    first_state = StateStore(str(tmp_path / "first.sqlite"))
    await _until_complete(world, first_state)
    first_state.close()
    assert A_DOCS <= set(world.reconciled[-1])
    last_success = world.stream(DRIVE).get("last_success_at")

    # Fresh local state; folder A's read is deferred (a 503 naming no minimum).
    world.unreadable["folder-a"] = real_deferral(503)
    path = str(tmp_path / "fresh.sqlite")
    state = StateStore(path)
    world.calls.clear()
    await world.run(state)
    progress = state.get_progress(world.namespace(DRIVE))
    assert progress.building_snapshot is not None  # the sibling keeps this build open
    assert _deferred(state, world)
    assert not _listed(world, "folder-a")
    state.close()

    # Restart: A's metadata recovers; the change feed is empty.
    world.unreadable.pop("folder-a")
    state = StateStore(path)
    summary = None
    for _ in range(40):
        mark = len(world.reconciled)
        summary = await world.run(state)
        for snapshot in world.reconciled[mark:]:
            assert A_DOCS <= set(snapshot), "a complete snapshot without folder A's subtree"
            assert _listed(world, "folder-a") and _listed(world, "folder-a-sub")
        if summary.authoritative_complete:
            break
        assert world.stream(DRIVE).get("last_success_at") == last_success  # not before completion
    assert summary is not None and summary.authoritative_complete
    assert _listed(world, "folder-a") and _listed(world, "folder-a-sub")
    for doc in A_DOCS:
        assert world.ledger.claims[doc] == {world.integration_id}  # the existing claims survive
        assert doc not in world.ledger.deleted
    assert not _deferred(state, world)
    state.close()


@pytest.mark.asyncio
async def test_retained_membership_never_keeps_a_document_the_recovered_listing_does_not_find(
    tmp_path, monkeypatch, clock,
):
    world = _world(monkeypatch)
    path = str(tmp_path / "retained.sqlite")
    state = StateStore(path)
    await _until_complete(world, state)
    assert A_DOCS <= set(world.reconciled[-1])

    # A rescan is seeded by a change to a folder under B; folder A's read is deferred during it.
    world.logs.setdefault(DRIVE, []).append({"fileId": "folder-b0", "file": dict(world.files["folder-b0"])})
    world.unreadable["folder-a"] = real_deferral(503)
    for _ in range(4):
        await world.run(state)
        progress = state.get_progress(world.namespace(DRIVE))
        if progress.building_snapshot is not None and _deferred(state, world):
            break
    assert progress.building_snapshot is not None and _deferred(state, world)

    # doc-a2 is gone at the provider, with no change this stream can see; A becomes readable again.
    world.files.pop("doc-a2")
    world.unreadable.pop("folder-a")
    mark = len(world.reconciled)
    summary = None
    for _ in range(40):
        before = len(world.reconciled)
        summary = await world.run(state)
        for snapshot in world.reconciled[before:]:
            assert "doc-a2" not in snapshot, "complete with stale retained membership"
        if summary.authoritative_complete:
            break
    assert summary is not None and summary.authoritative_complete
    assert len(world.reconciled) > mark
    assert "doc-a1" in world.reconciled[-1] and "doc-a2" not in world.reconciled[-1]
    assert (world.integration_id, "doc-a2") in world.ledger.retired
    assert _listed(world, "folder-a-sub")
    state.close()


@pytest.mark.asyncio
async def test_an_interrupted_recovered_listing_keeps_the_folder_deferred_and_resumes_after_restart(
    tmp_path, monkeypatch, clock,
):
    world = _world(monkeypatch, big_a=True, big_b=False)
    path = str(tmp_path / "interrupted.sqlite")
    state = StateStore(path)
    await _until_complete(world, state)
    a_docs = {doc for doc in world.files if doc.startswith("doc-a")}
    assert a_docs <= set(world.reconciled[-1])

    # Folder A is deferred during a controlled rescan, which publishes without it.
    world.logs.setdefault(DRIVE, []).append({"fileId": "folder-b", "file": dict(world.files["folder-b"])})
    world.unreadable["folder-a"] = real_deferral(503)
    for _ in range(6):
        await world.run(state)
        progress = state.get_progress(world.namespace(DRIVE))
        if progress.building_snapshot is None and _deferred(state, world):
            break
    assert _deferred(state, world)
    reconciled = len(world.reconciled)

    # A recovers; its listing needs more than one run's discovery budget.
    world.unreadable.pop("folder-a")
    world.calls.clear()
    interrupted = await world.run(state)
    # Part-way (A alone needs more listings than one run may make): still deferred, and nothing
    # was reconciled on a partial listing.
    assert not interrupted.authoritative_complete
    assert _deferred(state, world)
    assert len(world.reconciled) == reconciled
    state.close()

    state = StateStore(path)  # restart
    summary = await _until_complete(world, state)
    assert summary.authoritative_complete
    assert a_docs <= set(world.reconciled[-1])
    assert not _deferred(state, world)
    assert _listed(world, "folder-a")
    state.close()
